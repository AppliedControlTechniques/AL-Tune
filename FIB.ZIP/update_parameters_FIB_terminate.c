/*
 * update_parameters_FIB_terminate.c
 *
 * Code generation for function 'update_parameters_FIB_terminate'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "FIB_number.h"
#include "generate_FIB_range.h"
#include "update_parameters_FIB.h"
#include "update_parameters_FIB_terminate.h"
#include <stdio.h>

/* Function Definitions */
void update_parameters_FIB_terminate(void)
{
  /* (no terminate code required) */
}

/* End of code generation (update_parameters_FIB_terminate.c) */
