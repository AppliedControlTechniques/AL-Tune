/*
 * update_parameters_FIB_types.h
 *
 * Code generation for function 'FIB_number'
 *
 */

#ifndef __UPDATE_PARAMETERS_FIB_TYPES_H__
#define __UPDATE_PARAMETERS_FIB_TYPES_H__

/* Include files */
#include "rtwtypes.h"

/* Type Definitions */
#include <stdio.h>
#ifndef struct_emxArray_real_T_1x49
#define struct_emxArray_real_T_1x49
struct emxArray_real_T_1x49
{
    double data[49];
    int size[2];
};
#endif /*struct_emxArray_real_T_1x49*/
#ifndef typedef_emxArray_real_T_1x49
#define typedef_emxArray_real_T_1x49
typedef struct emxArray_real_T_1x49 emxArray_real_T_1x49;
#endif /*typedef_emxArray_real_T_1x49*/
#ifndef struct_emxArray_real_T_1x50
#define struct_emxArray_real_T_1x50
struct emxArray_real_T_1x50
{
    double data[50];
    int size[2];
};
#endif /*struct_emxArray_real_T_1x50*/
#ifndef typedef_emxArray_real_T_1x50
#define typedef_emxArray_real_T_1x50
typedef struct emxArray_real_T_1x50 emxArray_real_T_1x50;
#endif /*typedef_emxArray_real_T_1x50*/

#endif
/* End of code generation (update_parameters_FIB_types.h) */
