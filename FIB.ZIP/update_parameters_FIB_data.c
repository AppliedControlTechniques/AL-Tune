/*
 * update_parameters_FIB_data.c
 *
 * Code generation for function 'update_parameters_FIB_data'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "FIB_number.h"
#include "generate_FIB_range.h"
#include "update_parameters_FIB.h"
#include "update_parameters_FIB_data.h"
#include <stdio.h>

/* Variable Definitions */
double information_matrix[343];
double iteration;
double J;
double changed_parameter;

/* End of code generation (update_parameters_FIB_data.c) */
