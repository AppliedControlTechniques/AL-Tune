/*
 * generate_GLD_range_data.c
 *
 * Code generation for function 'generate_GLD_range_data'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "generate_GLD_range.h"
#include "update_parameters_GLD.h"
#include "generate_GLD_range_data.h"
#include <stdio.h>

/* Variable Definitions */
double information_matrix[399];
double iteration;
double J;
double changed_parameter;

/* End of code generation (generate_GLD_range_data.c) */
