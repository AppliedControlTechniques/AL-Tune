/*
 * generate_GLD_range.c
 *
 * Code generation for function 'generate_GLD_range'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "generate_GLD_range.h"
#include "update_parameters_GLD.h"
#include <stdio.h>

/* Function Definitions */
void generate_GLD_range(double i, double delta, const double current_range[2],
  double new_range[2])
{
  double length_old;
  (void)i;
  (void)delta;
  length_old = current_range[1] - current_range[0];
  new_range[0] = current_range[0] + 0.382 * length_old;
  new_range[1] = current_range[0] + 0.618 * length_old;
}

/* End of code generation (generate_GLD_range.c) */
