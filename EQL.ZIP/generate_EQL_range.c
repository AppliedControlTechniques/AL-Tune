/*
 * generate_EQL_range.c
 *
 * Code generation for function 'generate_EQL_range'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "generate_EQL_range.h"
#include "update_parameters_EQL.h"
#include <stdio.h>

/* Function Definitions */
void generate_EQL_range(double i, double delta, const double current_range[2],
  double new_range[2])
{
  double length_old;
  (void)i;
  (void)delta;
  length_old = current_range[1] - current_range[0];
  new_range[0] = current_range[0] + 0.125 * length_old;
  new_range[1] = current_range[0] + 0.875 * length_old;
}

/* End of code generation (generate_EQL_range.c) */
