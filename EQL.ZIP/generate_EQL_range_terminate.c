/*
 * generate_EQL_range_terminate.c
 *
 * Code generation for function 'generate_EQL_range_terminate'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "generate_EQL_range.h"
#include "update_parameters_EQL.h"
#include "generate_EQL_range_terminate.h"
#include <stdio.h>

/* Function Definitions */
void generate_EQL_range_terminate(void)
{
  /* (no terminate code required) */
}

/* End of code generation (generate_EQL_range_terminate.c) */
