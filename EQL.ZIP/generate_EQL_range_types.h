/*
 * generate_EQL_range_types.h
 *
 * Code generation for function 'generate_EQL_range'
 *
 */

#ifndef __GENERATE_EQL_RANGE_TYPES_H__
#define __GENERATE_EQL_RANGE_TYPES_H__

/* Include files */
#include "rtwtypes.h"

/* Type Definitions */
#include <stdio.h>
#ifndef struct_emxArray_real_T_1x57
#define struct_emxArray_real_T_1x57
struct emxArray_real_T_1x57
{
    double data[57];
    int size[2];
};
#endif /*struct_emxArray_real_T_1x57*/
#ifndef typedef_emxArray_real_T_1x57
#define typedef_emxArray_real_T_1x57
typedef struct emxArray_real_T_1x57 emxArray_real_T_1x57;
#endif /*typedef_emxArray_real_T_1x57*/
#ifndef struct_emxArray_real_T_1x58
#define struct_emxArray_real_T_1x58
struct emxArray_real_T_1x58
{
    double data[58];
    int size[2];
};
#endif /*struct_emxArray_real_T_1x58*/
#ifndef typedef_emxArray_real_T_1x58
#define typedef_emxArray_real_T_1x58
typedef struct emxArray_real_T_1x58 emxArray_real_T_1x58;
#endif /*typedef_emxArray_real_T_1x58*/

#endif
/* End of code generation (generate_EQL_range_types.h) */
