/*
 * generate_EQL_range.h
 *
 * Code generation for function 'generate_EQL_range'
 *
 */

#ifndef __GENERATE_EQL_RANGE_H__
#define __GENERATE_EQL_RANGE_H__

/* Include files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rtwtypes.h"
#include "generate_EQL_range_types.h"

/* Function Declarations */
#ifdef __cplusplus

extern "C" {

#endif

  extern void generate_EQL_range(double i, double delta, const double
    current_range[2], double new_range[2]);

#ifdef __cplusplus

}
#endif
#endif

/* End of code generation (generate_EQL_range.h) */
