/*
 * generate_DIC_range_terminate.c
 *
 * Code generation for function 'generate_DIC_range_terminate'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "generate_DIC_range.h"
#include "update_parameters_DIC.h"
#include "generate_DIC_range_terminate.h"
#include <stdio.h>

/* Function Definitions */
void generate_DIC_range_terminate(void)
{
  /* (no terminate code required) */
}

/* End of code generation (generate_DIC_range_terminate.c) */
