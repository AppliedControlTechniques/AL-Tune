/*
 * fileManager.c
 *
 * Code generation for function 'fileManager'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "generate_DIC_range.h"
#include "update_parameters_DIC.h"
#include "fileManager.h"
#include <stdio.h>

/* Function Definitions */
void fileManager(FILE * *f, boolean_T *a)
{
  *f = stdout;
  *a = true;
}

/* End of code generation (fileManager.c) */
