/*
 * generate_DIC_range_initialize.c
 *
 * Code generation for function 'generate_DIC_range_initialize'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "generate_DIC_range.h"
#include "update_parameters_DIC.h"
#include "generate_DIC_range_initialize.h"
#include "generate_DIC_range_data.h"
#include <stdio.h>

/* Named Constants */
#define b_iteration                    (0.0)
#define b_J                            (0.0)
#define b_changed_parameter            (1.0)

/* Function Definitions */
void generate_DIC_range_initialize(void)
{
  rt_InitInfAndNaN(8U);
  changed_parameter = b_changed_parameter;
  J = b_J;
  iteration = b_iteration;
  memset(&information_matrix[0], 0, 399U * sizeof(double));
}

/* End of code generation (generate_DIC_range_initialize.c) */
